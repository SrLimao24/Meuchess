@echo off
cd /d "%~dp0"
title Arena de Presentes

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado.
  echo Instale a versao LTS em https://nodejs.org e abra este arquivo de novo.
  pause
  exit /b
)

if not exist "node_modules\tiktok-live-connector\package.json" (
  echo Instalando a biblioteca do TikTok. Aguarde, pode demorar alguns minutos...
  call npm install
  if errorlevel 1 (
    echo.
    echo A instalacao falhou. Confira se o computador esta com internet e tente de novo.
    pause
    exit /b
  )
)

echo.
set /p USUARIO=Digite seu usuario do TikTok (sem o @). Deixe vazio para modo de teste:
echo.

if "%USUARIO%"=="" (
  node servidor.js --simular
) else (
  node servidor.js %USUARIO%
)
pause
