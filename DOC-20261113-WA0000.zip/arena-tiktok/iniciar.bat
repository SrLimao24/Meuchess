@echo off
cd /d "%~dp0"
title Arena de Presentes

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado.
  echo Instale a versao LTS em https://nodejs.org e abra este arquivo de novo.
  pause
  exit /b
)

if not exist node_modules (
  echo Instalando pela primeira vez. Aguarde, pode demorar um pouco...
  call npm install
)

echo.
set /p USUARIO=Digite seu usuario do TikTok (sem o @). Deixe vazio para modo de teste:
echo.

if "%USUARIO%"=="" (
  node servidor.js --simular
) else (
  node servidor.js %USUARIO%
)
pause
