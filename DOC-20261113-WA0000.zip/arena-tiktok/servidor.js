// Conector da Arena de Presentes.
// Faz duas coisas: (1) serve o jogo em http://localhost:3000 e
// (2) lê os presentes da live do TikTok e manda para o jogo em tempo real.
//
// Uso:
//   node servidor.js SEU_USUARIO     -> liga na sua live (você precisa estar ao vivo)
//   node servidor.js --simular       -> presentes falsos, sem TikTok (para testar)
//   node servidor.js SEU_USUARIO --depurar -> mostra no terminal o presente cru que chegou

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { exec } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const pasta = path.dirname(fileURLToPath(import.meta.url));
const publico = path.join(pasta, 'public');
const args = process.argv.slice(2);
const simular = args.includes('--simular');
const depurar = args.includes('--depurar');
const semNavegador = args.includes('--sem-navegador');
const usuario = (args.find((a) => !a.startsWith('--')) || '').replace(/^@/, '').trim();
const PORTA = Number(process.env.PORT) || 3000;

if (!simular && !usuario) {
  console.log('Faltou o seu usuario do TikTok.');
  console.log('Exemplo:  node servidor.js seu_usuario');
  console.log('Para testar sem live:  node servidor.js --simular');
  process.exit(1);
}

// ---------- envio de eventos para o jogo (Server-Sent Events) ----------
const clientes = new Set();
const estado = { modo: simular ? 'simulado' : 'tiktok', conectado: simular, usuario: usuario || null };

function enviar(evento) {
  const msg = `data: ${JSON.stringify(evento)}\n\n`;
  for (const res of clientes) res.write(msg);
}

// ---------- servidor web ----------
const tipos = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
};

const servidor = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (url.pathname === '/eventos') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });
    res.write('retry: 2000\n\n');
    res.write(`data: ${JSON.stringify({ tipo: 'status', ...estado })}\n\n`);
    clientes.add(res);
    req.on('close', () => clientes.delete(res));
    return;
  }

  if (url.pathname === '/status') {
    res.writeHead(200, { 'Content-Type': tipos['.json'] });
    res.end(JSON.stringify({ ...estado, espectadores: clientes.size }));
    return;
  }

  const alvo = url.pathname === '/' ? '/index.html' : url.pathname;
  const caminho = path.join(publico, path.normalize(alvo));
  if (!caminho.startsWith(publico)) {
    res.writeHead(403);
    res.end('Acesso negado');
    return;
  }
  fs.readFile(caminho, (erro, dados) => {
    if (erro) {
      res.writeHead(404);
      res.end('Nao encontrado');
      return;
    }
    res.writeHead(200, { 'Content-Type': tipos[path.extname(caminho)] || 'application/octet-stream' });
    res.end(dados);
  });
});

setInterval(() => {
  for (const res of clientes) res.write(': ping\n\n');
}, 20000);

// ---------- tradução do presente do TikTok para o jogo ----------
function pessoa(u = {}) {
  const nome = u.uniqueId || u.displayId || u.nickname || 'anonimo';
  const fotos = [
    ...(u.profilePicture?.url || []),
    ...(u.profilePicture?.urls || []),
    ...(Array.isArray(u.profilePicture) ? u.profilePicture : []),
    ...(u.profilePictureUrl ? [u.profilePictureUrl] : []),
  ].filter((f) => typeof f === 'string');
  const foto = fotos.find((f) => /\.(jpe?g|png|webp)/i.test(f)) || fotos[0] || null;
  return { nome: '@' + String(nome).replace(/^@/, ''), foto };
}

function diamantes(ev) {
  const unidade =
    ev.gift?.diamond_count ?? ev.gift?.diamondCount ??
    ev.extendedGiftInfo?.diamond_count ?? ev.extendedGiftInfo?.diamondCount ??
    ev.diamondCount ?? 1;
  return Math.max(1, Number(unidade) || 1) * Math.max(1, Number(ev.repeatCount) || 1);
}

// 1 a 9 diamantes = 1 nível, 10 a 99 = 2, 100 a 999 = 3... (máximo 6)
function niveis(total) {
  return Math.min(6, 1 + Math.floor(Math.log10(Math.max(1, total))));
}

function aoReceberPresente(ev) {
  if (depurar) console.log('PRESENTE CRU:', JSON.stringify(ev, (k, v) => (typeof v === 'bigint' ? String(v) : v)).slice(0, 1500));
  const tipo = ev.gift?.type ?? ev.giftType;
  // Presentes em sequência (tipo 1) chegam várias vezes; só conta quando a sequência termina.
  if (tipo === 1 && !ev.repeatEnd) return;
  const quem = pessoa(ev.user);
  const total = diamantes(ev);
  const nomePresente = ev.gift?.name ?? ev.extendedGiftInfo?.name ?? ev.giftName ?? 'presente';
  const n = niveis(total);
  console.log(`Presente de ${quem.nome}: ${nomePresente} (${total} diamantes) -> +${n} nivel`);
  enviar({ tipo: 'presente', nome: quem.nome, foto: quem.foto, presente: nomePresente, niveis: n });
}

// ---------- ligação com a live ----------
async function ligarNoTikTok() {
  let lib;
  try {
    lib = await import('tiktok-live-connector');
  } catch {
    console.log('A biblioteca do TikTok nao esta instalada. Rode primeiro:  npm install');
    process.exit(1);
  }
  const { TikTokLiveConnection, WebcastEvent } = lib;
  let tentando = false;

  const tentarDeNovo = () => {
    if (tentando) return;
    tentando = true;
    estado.conectado = false;
    enviar({ tipo: 'status', ...estado });
    console.log('Tentando de novo em 8 segundos...');
    setTimeout(() => { tentando = false; conectar(); }, 8000);
  };

  const conectar = () => {
    const conexao = new TikTokLiveConnection(usuario, { enableExtendedGiftInfo: true });
    conexao.on(WebcastEvent?.GIFT ?? 'gift', aoReceberPresente);
    conexao.on('disconnected', () => {
      console.log('Desconectou da live.');
      tentarDeNovo();
    });
    conexao.on('error', (e) => console.log('Aviso da biblioteca:', e?.message || e));
    conexao
      .connect()
      .then((s) => {
        estado.conectado = true;
        enviar({ tipo: 'status', ...estado });
        console.log(`Conectado na live de @${usuario} (sala ${s?.roomId ?? '?'}). Os presentes vao aparecer na arena.`);
      })
      .catch((e) => {
        console.log(`Nao consegui entrar na live de @${usuario}: ${e?.message || e}`);
        console.log('Confira se o usuario esta certo e se a live esta no ar.');
        tentarDeNovo();
      });
  };

  conectar();
}

function ligarSimulacao() {
  const nomes = ['@maria', '@joao_pa', '@ana.lu', '@pedrinho', '@bia_belem', '@carlos', '@thay', '@lucas77', '@duda', '@rafa'];
  const presentes = [['Rosa', 1], ['Rosa', 1], ['Rosa', 1], ['Leão', 3], ['Universo', 6]];
  setInterval(() => {
    const [presente, n] = presentes[Math.floor(Math.random() * presentes.length)];
    const nome = nomes[Math.floor(Math.random() * nomes.length)];
    console.log(`(simulado) ${nome}: ${presente} -> +${n} nivel`);
    enviar({ tipo: 'presente', nome, foto: null, presente, niveis: n });
  }, 1500);
  console.log('Modo simulado: presentes falsos a cada 1,5 segundo.');
}

servidor.listen(PORTA, () => {
  const endereco = `http://localhost:${PORTA}`;
  console.log(`Jogo no ar em ${endereco}`);
  console.log(`Para a transmissao, abra ${endereco}/?limpo (sem botoes de teste).`);
  if (!semNavegador) {
    const abrir = process.platform === 'win32' ? 'start ""' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    exec(`${abrir} ${endereco}`, () => {});
  }
  if (simular) ligarSimulacao();
  else ligarNoTikTok();
});
